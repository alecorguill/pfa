package neoblik;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.*;

import beans.Player;
import model.Players;
import form.FormPlayer;

public class ChoixJeu extends HttpServlet {

	public static final String VUE = "/WEB-INF/choix_jeu.jsp";	
    public static final String CHAMP_PSEUDO = "pseudo";
	
	public void doGet( HttpServletRequest request, HttpServletResponse response )   throws ServletException, IOException {
		
		this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
	}
	
    public void doPost( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{
        this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
    	
    }
    
}