package neoblik;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import model.*;

public class Board extends HttpServlet {

	public static final String VUE = "/WEB-INF/board.jsp";
	
	public void doGet( HttpServletRequest request, HttpServletResponse response )   throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		ServletContext context = this.getServletContext();
		
		beans.Player player = (beans.Player) session.getAttribute("player");
		GameServer serveur = (GameServer)context.getAttribute("serveur");
		
		if(serveur != null)
			session.setAttribute("players", serveur.getPlayers());

		String toPlay = serveur.getPlayerToPlay();
		System.out.println("-------------------------------");
		System.out.println(toPlay);
		System.out.println("-------------------------------");
		request.setAttribute("toPlay", toPlay);
		this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
	}
	  
}