package neoblik;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import model.*;

public class Board extends HttpServlet {

	public static final String VUE = "/WEB-INF/board.jsp";
	
	public void doGet( HttpServletRequest request, HttpServletResponse response )   throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		ServletContext context = this.getServletContext();
		
		beans.Player player = (beans.Player) session.getAttribute("player");
		GameServer serveur = (GameServer)context.getAttribute("serveur");
		
		if(serveur != null){
			//On indique le joueur qui doit jouer
			String toPlay = serveur.getPlayerToPlay();
			request.setAttribute("toPlay", toPlay);
			int pot = serveur.getPotValue();
			request.setAttribute("toPlay", toPlay);
			//On passe en parametre les valeur des cartes du board
			String[] tab = new String[10];
			int i;
			for(i = 0; i<=8; i=i+2){
				tab[i] = "";
				tab[i+1] = "back";
			}
			ArrayList<Card> board = serveur.getBoard();
			if(board != null){
				for(i=0; i<board.size(); ++i){
					Card c = board.get(i);
					if(c != null) {
					tab[2*i] = c.getValueAsString();
					tab[2*i+1] = c.getSuitAsString();
					}
				}
			}
			
			for(i=0; i<tab.length; i=i+2){
				response.addHeader("val"+i, tab[i]);
				response.addHeader("color"+i, tab[i+1]);
			}
			//On met l'indice du dealer en attribut
			response.addHeader("indexDealer", String.valueOf(serveur.getIndexDealer()));
			//On Construit le tableau des pseudo des joueur
			Players ps = (Players) context.getAttribute("players");
			response.addHeader("nbPlayer", String.valueOf(ps.nbPlayers()));
			i=0;
			for(beans.Player p : ps.getPlayers()){
				response.addHeader("player"+i, p.getPseudo());
				i++;
			}
		}
		this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
	}
	  
}