package neoblik;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.servlet.ServletContext;
import beans.Player;
import form.FormPlayer;
import model.Players;
import model.Serveur;

public class Accueil extends HttpServlet {
    public static final String VUE = "/WEB-INF/accueil.jsp";
    public static final String CHAMP_PSEUDO = "pseudo";

    public void doGet( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{
        /* Affichage de la page d'inscription */
    	ServletContext context = this.getServletContext();
    	
    	if(context.getAttribute("players") == null){
    		context.setAttribute("players", new Players());
    	}
    	
        this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
    }
    
    public void doPost( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{
        /* Traitement des données du formulaire */
    	//Initialisation des contexes et variables
    	ServletContext context = this.getServletContext();
    	HttpSession session = request.getSession();
		Players p = (Players) context.getAttribute("players");
		
    	String device  = (String)session.getAttribute("device");
		if(device == null){
			session.setAttribute("device", "tablette");
		}
    	
		//On ajoute le joueur
    	String pseudo = request.getParameter( CHAMP_PSEUDO );
    	//Cas ou on va rediriger
    	if(pseudo != null && pseudo.length() >= 1){
    		FormPlayer form = new FormPlayer();	
    		Player player = form.signPlayer(request);
    		session.setAttribute("player", player);
    		p.addPlayer(player);
    		System.out.print(( (Players)(context.getAttribute("players")) ).nbPlayers());
        	if( ( (Players)(context.getAttribute("players")) ).nbPlayers() <= 1 ){
        		player.setIsAdmin(true);
        		response.sendRedirect("choix_jeu");
        	}
        	else {
    		response.sendRedirect("lobby");
        	}
    	}
    	else{
    		String message = "Erreur de pseudo";
    		request.setAttribute("message",message);
    		this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
    	}      
    	
    }
}