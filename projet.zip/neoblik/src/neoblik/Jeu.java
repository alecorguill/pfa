package neoblik;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.*;

import beans.Player;
import form.FormPlayer;

import javax.servlet.ServletContext;

import java.net.*;
import java.util.concurrent.TimeUnit;
import java.io.*;

import model.Players;
import model.Serveur;

public class Jeu extends HttpServlet {
    public static final String VUE = "/WEB-INF/jeu.jsp";

    public void doGet( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{
        /* Affichage de la page d'inscription */
    	//Serveur serveur = new Serveur();
    	//Redirection page choix des jeu si c'est le premier joueur
    	ServletContext context = this.getServletContext();
		Serveur currentServer = (Serveur)context.getAttribute("serveur");
		String message;
		if(currentServer == null){
			message = "Jeu non demarre";
		}
		else {
			message = currentServer.message;
		}
		request.setAttribute("message", message);
    	
    	if(context.getAttribute("serveur") == null){
    		Serveur serveur = new Serveur();
    		   		
    		Thread t = new Thread(serveur);
    		t.start();
    		
    		context.setAttribute("serveur", serveur);
    		
    		try{
    			TimeUnit.SECONDS.sleep(1);
    		}
    		catch(Exception e){
    		}
    		
    		System.out.println(serveur.toString());
    		
    	
    	}
    	this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
    }
        public void doPost( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{
            /* Traitement des données du formulaire */
        	String bool = request.getParameter( "unlock" );
        	ServletContext context = this.getServletContext();
    		String message;
        	Serveur serveur = (Serveur)context.getAttribute("serveur");
        	if(bool.equals("true")){
        		serveur.setMessage("Jeu débloqué");
        	}
    		if(serveur == null){
    			message = "Jeu non demarre";
    		}
    		else {
    			message = serveur.message;
    		}
    		System.out.println(serveur.toString());
    		request.setAttribute("message", message);
            this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
        	
        }
    		
}
    
