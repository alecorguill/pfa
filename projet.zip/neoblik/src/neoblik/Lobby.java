package neoblik;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Players;
import model.Serveur;
import model.GameServer;
import beans.Player;
import form.FormPlayer;

import java.net.*;
import java.util.concurrent.TimeUnit;
import java.io.*;

public class Lobby extends HttpServlet {

	public static final String VUE = "/WEB-INF/lobby.jsp";	
    public static final String CHAMP_PSEUDO = "pseudo";
    public static final String CHAMP_LAUNCH = "launch";
    
	public void doGet( HttpServletRequest request, HttpServletResponse response )   throws ServletException, IOException {
		
		//Initialisation des contextes
		HttpSession session = request.getSession();
		ServletContext context = this.getServletContext();
    	response.addHeader("Access-Control-Allow-Origin", "*");
		
		String game = (String) request.getParameter("game");
		
		if(game != null){
			context.setAttribute("game", game);
		}
		
    	//On redirige si le jeu est lanc�
		if(context.getAttribute("launch") != null){
			boolean launch = (boolean)context.getAttribute("launch");
			
			if(launch)
			{
				String device  = (String)session.getAttribute("device");
				String url_tablette   = "tablet";
				String url_smartphone = "smartphone";
				
				if(device.equals("smartphone")){
					response.setHeader("location", url_smartphone);
				}
				else {
					response.setHeader("location",url_tablette);
				}   
			}
		}
		
		//Ligne pour empecher le bug differentes origin avec le load avec la borne
		this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
	}
	
    public void doPost( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{
    	
    	//Initialisation des contexes et variables
    	ServletContext context = this.getServletContext();
    	HttpSession session = request.getSession();
		Players p = (Players) context.getAttribute("players");
    	
    	//Cas ou on arrive de accueil (vou� a changer pour traiter
    	//la r�ponse sur la page d'accueil
    	String pseudo = request.getParameter( CHAMP_PSEUDO );
    	
    	if(pseudo != null){
    		FormPlayer form = new FormPlayer();	
    		Player player = form.signPlayer(request);
    		session.setAttribute("player", player);
    		p.addPlayer(player);
    	}
    	
    	//On traite le cas ou l'admin lance le jeu (ajax call)
    	if(request.getParameter( CHAMP_LAUNCH ) != null){
    		boolean launch = true;
    		
    		// On lance le serveur
        	if(context.getAttribute("serveur") == null){
        		GameServer serveur = new GameServer(p.nbPlayers());
        		context.setAttribute("serveur", new Serveur());
        		
        		serveur = (GameServer)context.getAttribute("serveur");
        		
        		Thread t = new Thread(serveur);
        		t.start();
        	}
     
        		context.setAttribute("launch", launch);
    		
    	}
    	
    	this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
    }
}
