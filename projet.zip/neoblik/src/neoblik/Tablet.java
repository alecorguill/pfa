package neoblik;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.*;

import model.*;
import beans.Player;
import form.FormPlayer;


public class Tablet extends HttpServlet {

	public static final String VUE = "/WEB-INF/tablet.jsp";
	
	public void doGet( HttpServletRequest request, HttpServletResponse response )   throws ServletException, IOException {
    	/* Traitement des boutons des tablettes */
    	//Initialisation des contextes
		/*
    	HttpSession session = request.getSession();
		ServletContext context = this.getServletContext();
		
		GameServer serveur = (GameServer) context.getAttribute("serveur");
		beans.Player player = (beans.Player) session.getAttribute("player");
		String bool = "false";
		if(serveur != null){
			if(player.getPseudo().equals(serveur.getPlayerToPlay())){
				bool = "true";	
			}
			else {
				bool = "false";
			}
		}
		response.addHeader("iPlay", bool);
		*/
		this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
	}
	
    public void doPost( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{
    
    	/* Traitement des boutons des tablettes */
    	//Initialisation des contextes
    	HttpSession session = request.getSession();
		ServletContext context = this.getServletContext();
		
		GameServer serveur = (GameServer) context.getAttribute("serveur");
		beans.Player player = (beans.Player) session.getAttribute("player");
		
		//On test si c'est bien le joueur qui doit jouer
		
		//On transforme la requete en move on l'envoie au serveur
		//Et on envoie les info du joueur a la vue tablette
		if(serveur != null && player.getPseudo().equals(serveur.getPlayerToPlay())){
			model.Player playerModel = (model.Player) serveur.getPlayer(player.getPseudo());
			request.setAttribute("stack", playerModel.getStack());
			int value = Integer.parseInt(request.getParameter("value"));
			String move = request.getParameter( "move" );
			System.out.println(move);
			if(move != null){
				Move m = new Move(move,value);
				serveur.setMove(m);
			}
    	
		}
		
        this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
    	
    }
    
}