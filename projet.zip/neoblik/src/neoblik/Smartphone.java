package neoblik;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.*;

import model.*;

public class Smartphone extends HttpServlet {

	public static final String VUE = "/WEB-INF/smartphone.jsp";
	
	public void doGet( HttpServletRequest request, HttpServletResponse response )   throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		ServletContext context = this.getServletContext();
		
		GameServer serveur = (GameServer) context.getAttribute("serveur");
		beans.Player player = (beans.Player) session.getAttribute("player");
		
		String card1Value;
		String card1Suit;
		String card2Value;
		String card2Suit;
		
		if(serveur != null){
			if(player != null){
				Player p = serveur.getPlayer(player.getPseudo());
				if(p != null){
					Card[] cards = p.getHand();
					card1Value = cards[0].getValueAsString();
					card1Suit = cards[0].getSuitAsString();
					card2Value = cards[1].getValueAsString();
					card2Suit = cards[1].getSuitAsString();
					
					response.addHeader("card1Value", card1Value);
					response.addHeader("card1Suit", card1Suit);
					response.addHeader("card2Value", card2Value);
					response.addHeader("card2Suit", card2Suit);
				}
			}
				
		}
		
		this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
	}
    
}