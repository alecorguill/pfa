package model;

import javax.servlet.ServletContext;
import java.net.*;
import java.io.*;
import java.util.Random;
public class Serveur implements Runnable{
	public boolean servletBlocking;
	public String message;
	public int id;

	public Serveur(){
		servletBlocking = true;
		message="Jeu Instanci�";
		Random r = new Random();
		id = r.nextInt(1000);
	}
	
	public void run(){
		while(this.servletBlocking){
			message = "Jeu blocked";
		}
		message="Jeu d�bloqu�";
	}
	
	public boolean getServletBlocking() {
		return servletBlocking;
	}
}