package model;

import javax.servlet.ServletContext;

import java.net.*;
import java.io.*;
import java.util.Random;
import java.util.concurrent.TimeUnit;
public class Serveur implements Runnable{
	public boolean servletBlocking;
	public String message;
	public int id;

	public Serveur(){
		servletBlocking = true;
		message="Jeu Instancie";
		Random r = new Random();
		id = r.nextInt(1000);
	}
	
	public void run(){
		while(this.servletBlocking){
			message = "Jeu blocked";
			//System.out.println(servletBlocking);
			try{
				//TimeUnit.SECONDS.sleep(2);
			} catch(Exception e){}
		}

		message="Jeu debloque";
	}
	
	public boolean getServletBlocking() {
		return servletBlocking;
	}
}