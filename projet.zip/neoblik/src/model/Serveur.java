package model;

import javax.servlet.ServletContext;

import java.net.*;
import java.io.*;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.*;

public class Serveur implements Runnable{
	public String message;
	public boolean servletBlocking;
	public int id;
	private Lock lm = new ReentrantLock();
	private Lock ls = new ReentrantLock();
	
	public Serveur(){
		servletBlocking = true;
		message="Jeu Instancie";
		Random r = new Random();
		id = r.nextInt(1000);
	}
	
	public void setMessage(String m){
		lm.lock();
		this.message = m;
		lm.unlock();
		ls.lock();
		servletBlocking = false;
		ls.unlock();
	}
	
	public void run(){
		boolean blocking = true;
		while(blocking){
			ls.lock();
			blocking = servletBlocking;
			ls.unlock();
			lm.lock();
			message = "Jeu bloqué";
			lm.unlock();
		}
	}
}