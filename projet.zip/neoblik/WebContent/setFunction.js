    
card1 = "card1";
card2 = "card2";
card3 = "card3";
card4 = "card4";
card5 = "card5";

function card_change( card, val, color ){
        //modification of the card in the html file 
        var elt = document.getElementById(card);
        elt.className = 'card rank-'+ val +' ' + color;

        var elt2 = elt.getElementsByTagName("span");
        elt2[0].textContent = val;
        var colorchar = '';
        if (color === "Clubs")
        {
        	colorchar = '<img src="img/club.jpg" alt="clubsymbol">';
        } 
        else if (color === "Spades")
        {
    	colorchar = '<img src="img/spade.jpg" alt="spadesymbol">';
        }
        else if (color === "Hearts")
        {
    	colorchar = '<img src="img/heart.jpg" alt="heartymbol">';
        }
        else if (color === "Diams")
        {
    	colorchar = '<img src="img/diamond.jpg" alt="diamondsymbol">';
        }

        //elt2[1].innerHTML = "<span class=symb>" + colorchar  +"</span>";
        elt2[1].innerHTML = colorchar;
    }
    
function set_hand(val1, color1, val2, color2){

        
        //modification of the first card in the html file HAND.html
        card_change(card1, val1, color1);

        //modification of the second card
        card_change(card2, val2, color2);
        
    }
    
    
function set_board_position(indexdealer, players){
    var elt = document.getElementById('placement');
    var elt2 = elt.getElementsByTagName('div');
    var nbplayers = players.length;
    if(nbplayers ==2){
	if(indexdealer == 0){
	    elt2[(10-(indexdealer+nbplayers))%10].innerHTML = players[(indexdealer - 1 +nbplayers) % nbplayers];
	}
	else{
	    elt2[(10-(indexdealer))%10].innerHTML = players[(indexdealer - 1 +nbplayers) % nbplayers];
	}
	
	if(indexdealer + 2 > nbplayers){
	    elt2[(10-(indexdealer+2)+nbplayers)%10].innerHTML = players[(indexdealer + 1)%nbplayers] + '<img src="img/bigb.png" alt="BB">';
	}
	else {
	    elt2[(10-(indexdealer+2)+10)%10].innerHTML = players[(indexdealer + 1)%nbplayers] + '<img src="img/bigb.png" alt="BB">';
	}
	elt2[10-(indexdealer+1)].innerHTML = players[indexdealer] + '<img src="img/dealer.png" alt="dealer">';
    }
    else{
	if(indexdealer == 0){
	    elt2[(10-(indexdealer+nbplayers))%10].innerHTML = players[(indexdealer - 1 +nbplayers) % nbplayers];
	}
	else{
	    elt2[(10-(indexdealer))%10].innerHTML = players[(indexdealer - 1 +nbplayers) % nbplayers];
	}
	
	if(indexdealer + 2 > nbplayers){
	    elt2[(10-(indexdealer+2)+nbplayers)%10].innerHTML = players[(indexdealer + 1)%nbplayers] + '<img src="img/smallb.png" alt="SB">';
	    elt2[(10-(indexdealer+3)+nbplayers)%10].innerHTML = players[(indexdealer + 2)%nbplayers] + '<img src="img/bigb.png" alt="BB">';
	}
	else if(indexdealer + 3 > nbplayers){
	    elt2[(10-(indexdealer+2)+10)%10].innerHTML = players[(indexdealer + 1)%nbplayers] + '<img src="img/smallb.png" alt="SB">';
	    elt2[(10-(indexdealer+3)+nbplayers)%10].innerHTML = players[(indexdealer + 2)%nbplayers] + '<img src="img/bigb.png" alt="BB">';
	}
	else {
	    elt2[(10-(indexdealer+2)+10)%10].innerHTML = players[(indexdealer + 1)%nbplayers] + '<img src="img/smallb.png" alt="SB">';
	    elt2[(10-(indexdealer+3)+10)%10].innerHTML = players[(indexdealer + 2)%nbplayers] + '<img src="img/bigb.png" alt="BB">';
	}
	elt2[10-(indexdealer+1)].innerHTML = players[indexdealer] + '<img src="img/dealer.png" alt="dealer">';
    }
}

    
    
function set_board(tab){
    	var i;
    	for(i = 0; i <= tab.length-2; i = i+2){
    		var number_card = i/2 + 1;
    		var card = "card" + number_card;
    		card_change(card,tab[i],tab[i+1]);
    	}   
    }
    
    
function set_board_placement(players){
    var elt = document.getElementById('placement');
    switch(players.length){
    case 10:
	elt.innerHTML = '<div class="dix">'+ players[9] +'</div><div class="neuf">'+ players[8] +' </div><div class="huit"> ' + players[7] +' </div><div class="sept"> ' + players[6] +' </div><div class="six"> ' + players[5] +'  </div><div class="cinq"> ' + players[4] +' </div><div class="quatre"> ' + players[3] +' </div><div class="trois"> ' + players[2] +' </div><div class="deux"> ' + players[1] +' </div><div class="un"> ' + players[0] +' </div>';
	break;
    case 9:
	elt.innerHTML = '<div class="dix"> &nbsp </div><div class="neuf"> ' + players[8] +' </div><div class="huit"> ' + players[7] +' </div><div class="sept"> ' + players[6] +' </div><div class="six"> ' + players[5] +'  </div><div class="cinq"> ' + players[4] +' </div><div class="quatre"> ' + players[3] +' </div><div class="trois"> ' + players[2] +' </div><div class="deux"> ' + players[1] +' </div><div class="un"> ' + players[0] +' </div>';
	break;
    case 8:
	elt.innerHTML = '<div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="huit"> ' + players[7] +' </div><div class="sept"> ' + players[6] +' </div><div class="six"> ' + players[5] +' </div><div class="cinq"> ' + players[4] +' </div><div class="quatre"> ' + players[3] +' </div><div class="trois"> ' + players[2] +' </div><div class="deux"> ' + players[1] +' </div><div class="un"> ' + players[0] +' </div>';
	break;
    case 7:
	elt.innerHTML = '<div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="sept"> ' + players[6] +' </div><div class="six"> ' + players[5] +'  </div><div class="cinq"> ' + players[4] +' </div><div class="quatre"> ' + players[3] +' </div><div class="trois"> ' + players[2] +' </div><div class="deux"> ' + players[1] +' </div><div class="un"> ' + players[0] +' </div>';
	break;
    case 6:
	elt.innerHTML = '<div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="six"> ' + players[5] +'  </div><div class="cinq"> ' + players[4] +' </div><div class="quatre"> ' + players[3] +' </div><div class="trois"> ' + players[2] +' </div><div class="deux"> ' + players[1] +' </div><div class="un"> ' + players[0] +' </div>';
	break;
    case 5:
	elt.innerHTML = '<div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="cinq"> ' + players[4] +' </div><div class="quatre"> ' + players[3] +' </div><div class="trois"> ' + players[2] +' </div><div class="deux"> ' + players[1] +' </div><div class="un"> ' + players[0] +' </div>';
	break;
    case 4:
	elt.innerHTML = '<div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="quatre"> ' + players[3] +' </div><div class="trois"> ' + players[2] +' </div><div class="deux"> ' + players[1] +' </div><div class="un"> ' + players[0] +' </div>';
	break;
    case 3:
	elt.innerHTML = '<div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="trois"> ' + players[2] +' </div><div class="deux"> ' + players[1] +' </div><div class="un"> ' + players[0] +' </div>';
	break;
    case 2:
	elt.innerHTML = '<div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="dix"> &nbsp </div><div class="deux"> ' + players[1] +' </div><div class="un"> ' + players[0] +' </div>';
	break;

    default:
	alert("nombre de joueurs incohérent");
	break;
    }
}
    